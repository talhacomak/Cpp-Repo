This program will run from the command line with the following format:
./program algorithmType N file
N: Total number of integers to be sorted
algorithmType: Method to be used to sort( ’b’ for Bubblesort or ’m’ for Merge Sort)
file: Input file to be read ("sorted.txt" or "unsorted.txt").
An example execution command is given as follows:
./program m 1000 sorted.txt
This command executes the program using Merge sort with the first 1000 elements of
the file "sorted.txt".